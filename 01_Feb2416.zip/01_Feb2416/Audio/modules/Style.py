# Brutal Editor
# Audio V0
# Style.py
# >>> python2
# Feb 15, 2016
# 
# Style
#

size_app_minw = 900
size_app_minh = 540
size_app_maxw = 900
size_app_maxh = 540

size_opt_width = 200
size_opt_height = 200

colour_app_foreground = '#000000'
colour_app_background = '#F8F8F8'
colour_frame_background = '#A0A0A0'

colour_graph_background = '#FF0000'
colour_graph_lines = '#000000'

colour_button = '#F0F0F0'
colour_entry  = '#F8F8F8'
colour_label  = '#858585'
colour_label_header = '#656565'

widget_bottom_height = 22

###
