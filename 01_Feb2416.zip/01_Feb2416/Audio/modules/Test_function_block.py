"""
JUST FOR TESTS
"""
# Brutal Editor
# Audio V0
# python_main.py
# >>> python2
# Dec 14, 2015
#
# main function for audio 
# - just initialize and go
#

import Tkinter as tk
import Application
import threading
import Function_Block
import Audio



def run_application():

	root = tk.Tk()
	root.config(bg='black', width=600, height=540)
	a = Audio.Audio_File()

	###
	### swap 0,1 for function,filter
	app = Function_Block.Function_Block(0, master=root, audio_file=a)
	###
	app.master.title('Test Blocks')
	app.mainloop()

if __name__ == "__main__":
	"""
	t = threading.Thread(None, run_application, 'Making Graphs')
	t.start()
	t.join()
	"""
	run_application()
