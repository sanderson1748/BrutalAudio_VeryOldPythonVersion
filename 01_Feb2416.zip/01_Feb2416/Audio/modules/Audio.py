# Brutal Editor
# Audio V0
# Audio.py
# >>> python2
# Dec 16, 2015
# 
# Audio class to interact with cpp
# - has file info to interact with py then pump back to cpp
#

import os
import threading
import numpy as np

from File_Type import Wav

class Audio_Exception():
	def __init__(self, n, s=''):
		#if n == 0:
		self.value = 'Audio Error' + s

	def __str__(self):
		return repr(self.value)

# add an [args] parameter to the guy
# --> if args.tell_me
class Audio_File():
	def __init__(self):
		# (info)
		self.flavour = 'wav' 
		self.file_time = 5.0	# seconds
		self.amp_max = 2.0
		self.file_loc = 'Brutal/'
		self.file_name = 'output'

		# functions 
		self.base_function = ()
		self.functions = []
		self.filters = []

		# physical
		self.physical_data = (16, 2, 44100, 4, 8)

		# fill
		self.base_function = (np.sin, 1, 440, 0, 0)
		self.functions.append((np.sin, 0.5, 880, 0, 0))
		self.filters.append((np.sin, 1, 1, 0, 0))

	# returns all info as:
	# [ (info), (base_function), [(functions0), ..], [(filters0), ..], (physical_data) ]
	# (info) = (flavour, file_time, amp_max, file_loc, file_name)
	#
	def get_all(self):
		ret = []
		ret.append((self.flavour, self.file_time, self.amp_max, self.file_loc, self.file_name))
		ret.append(self.base_function)
		ret.append(self.functions)
		ret.append(self.filters)
		ret.append(self.physical_data)
		return ret

	def get_flavour(self):
		return self.flavour

	def get_file_time(self):
		return self.file_time

	def get_amp_max(self):
		return self.amp_max

	def get_full_location(self):
		if not self.file_loc.endswith('/'):
			self.file_loc += '/'
		return self.file_loc + self.file_name

	def get_physical(self):
		return self.physical_data

	def set_file_loc(self, floc_in):
		try:
			self.file_loc = floc_in
		except:
			self.file_loc = './'

	def set_file_time(self, n):
		try:
			self.file_time = n
		except:
			self.file_time = 5.0
			print('Audio.set_file_time error, n = ' + str(n))

	# called by Option_Window.finish()
	def set_amp_max(self, n):
		try:
			self.amp_max = n
		except:
			self.amp_max = 2.0

	def set_file_name(self, fname_in):
		try:
			self.file_name = fname_in
		except:
			self.file_name = 'output'

	def set_physical(self, phys_in):
		#try:
		#	if len(check) == 5:
		self.physical_data = phys_in
		#	else:
		#		raise
		#except:
		#	self.physical_data = (16, 2, 44100, 4, 8)

	# updates info from Function_Block.update_audio
	# clear, update
	# data_in is:
	# 	( fun/fil(0/1), [(functions0), .. )
	#	functions are:
	# 		( type, amp, freq, phi, const )
	def update_audio(self, data_in):
		#print('Audio.update_all: data_in is: ' + str(data_in))

		if data_in[0] == 0:
			#print ('Audio.update_audio: updating functions')

			#self.functions.clear() #python3
			try:
				del self.base_function
			except AttributeError:
				print ('Audio.update_audio delete base function error' )

			for i in range(len(self.functions)):
				self.functions.pop(0)

			try:
				self.base_function = data_in[1][0]
			except IndexError: 
				#print ('Audio.update_audio updating functions data_in does not have first entry')
				self.base_function = (np.sin, 1.0, 440, 0, 0)

			for i in range(1, len(data_in[1])):
				self.functions.append(data_in[1][i])

		elif data_in[0] == 1:
			#print ('Audio.update_audio updating filters')

			#self.filters.clear() #python3
			for i in range(len(self.filters)):
				self.filters.pop(0)
				
			for i in range(len(data_in[1])):
				self.filters.append(data_in[1][i])

		else:
			raise Audio_Exception(0, 'Audio_File.update_audio has not chosen function or filter')

	# make sure to update physical_data before calling
	def get_processed(self):
		#print ('Audio.get_processed')
		if self.flavour == 'wav':
			Wav.process_wav(self.get_all())
		else:
			raise Audio_Exception(0, 'Audio.get_processed not correct type')

	# called by Function_Block.save_file
	# passed fname_in to update file name (from entry)
	def save_file(self):
		#print ('Audio.save_file')
		self.get_processed()
		
###
