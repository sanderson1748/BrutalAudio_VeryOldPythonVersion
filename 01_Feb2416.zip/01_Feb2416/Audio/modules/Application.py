# Brutal Editor
# Audio V0
# Application.py
# >>> python2
# Dec 14, 2015
# 
# main application window
# - main window, has controls and contains the graph widget
#

import Tkinter as tk
import threading

import Audio
import Function_Block
import Option_Window
import Graph
import Style

colour_frame_background = Style.colour_frame_background
colour_button = Style.colour_button
colour_entry  = Style.colour_entry
colour_label  = Style.colour_label

widget_bottom_height = Style.widget_bottom_height

class Audio_Application(tk.Frame):
	def __init__(self, master=None):
		tk.Frame.__init__(self,master)

		self.audio_files = [Audio.Audio_File()]
		self.session_save = 0

		self.place()
		self.load_widgets()

	# Ready everything
	def load_widgets(self):
		# Options
		option_window_window = tk.Tk()
		self.option_window = Option_Window.Option_Window(self.audio_files[0], master=option_window_window)
		self.option_window.master.withdraw()

		# Graph
		self.graph_frame = tk.Frame(self.master)
		self.graph_frame.place(relx=0.0125, rely=0.0125, relwidth=0.975, relheight=0.450)
		self.graph = Graph.Graph_Window(self.graph_frame, audio_file=self.audio_files[0])

		# Audio Options
		self.entry_ftime = tk.Entry(self.master, bg=colour_entry, justify=tk.RIGHT)
		self.entry_ftime.insert(0, '5.0')
		self.entry_ftime.bind(sequence='<FocusOut>', func=self.check_entry_ftime)
		self.entry_ftime.place(relx=0.6450, rely=0.4750, relwidth=0.045, relheight=0.05)
		self.label_ftime = tk.Label(self.master, text='File Time', bg=colour_label, justify=tk.RIGHT)
		self.label_ftime.place(relx=0.6900, rely=0.4750, relwidth=0.120, relheight=0.05)

		self.entry_fmax = tk.Entry(self.master, bg=colour_entry, justify=tk.RIGHT)
		self.entry_fmax.insert(0, '2.0')
		self.entry_fmax.bind(sequence='<FocusOut>', func=self.check_entry_fmax)
		self.entry_fmax.place(relx=0.8225, rely=0.4750, relwidth=0.045, relheight=0.05)
		self.label_fmax = tk.Label(self.master, text='Max Amplitude', bg=colour_label, justify=tk.RIGHT)
		self.label_fmax.place(relx=0.8675, rely=0.4750, relwidth=0.120, relheight=0.05)

		# Functions
		self.functions_frame = tk.Frame(master=self.master)
		self.functions_frame.config(bg=colour_frame_background)
		self.functions_frame.place(relx=0.0125, rely=0.5375, relwidth=0.48125, relheight=0.4000)
		self.functions = Function_Block.Function_Block(0, master=self.functions_frame, audio_file=self.audio_files[0])

		self.filters_frame = tk.Frame(master=self.master)
		self.filters_frame.config(bg=colour_frame_background)
		self.filters_frame.place(relx=0.50625, rely=0.5375, relwidth=0.48125, relheight=0.4000)
		self.filters = Function_Block.Function_Block(1, master=self.filters_frame, audio_file=self.audio_files[0])

		# Controls
		self.button_update = tk.Button(text='Update Graph', bg=colour_button, command=self.update_file)
		self.button_update.place(relx=0.00, rely=0.95, relwidth=0.25, relheight=0.05)

		self.button_options = tk.Button(text='File Options', bg=colour_button, command=self.open_options)
		self.button_options.place(relx=0.25, rely=0.95, relwidth=0.25, relheight=0.05)

		self.button_save= tk.Button(text='Save File', bg=colour_button, command=self.save_file)
		self.button_save.place(relx=0.50, rely=0.95, relwidth=0.25, relheight=0.05)

		self.button_quit = tk.Button(text='Done', bg=colour_button, command=self.finish)
		self.button_quit.place(relx=0.75, rely=0.95, relwidth=0.25, relheight=0.05)

	# self.option_window is alays working; just hides
	def open_options(self):
		try:
			check = self.option_window.master.state()
		except tk.TclError:
			option_window_window = tk.Tk()
			self.option_window = Option_Window.Option_Window(self.audio_files[0], master=option_window_window)
			self.option_window.master.withdraw()
			check = self.option_window.master.state()
		except: 
			raise Audio.Audio_Error(0, 'Application.open_options self.option_window invalid state')

		if check == 'withdrawn':
			self.option_window.master.state('normal')
		elif check == 'normal':
			pass
		else:
			raise Audio.Audio_Exception(0, 'Application.open_options option_window check invalid')

	def check_entry_ftime(self, event):
		try:
			hold = float(self.entry_ftime.get())
		except:
			self.entry_ftime.delete(0, 1000)
			self.entry_ftime.insert(0, '5.0')

	def check_entry_fmax(self, event):
		try:
			hold = float(self.entry_fmax.get())
		except:
			self.entry_fmax.delete(0, 1000)
			self.entry_fmax.insert(0, '12.0')

	# updates audio_file and physical properties
	# call before all other update functions
	def update_from_application(self):
		# Option Window
		self.option_window.update_to_application()

		# fTime and fMax
		ftime = self.entry_ftime.get()
		try:
			ftime = float(ftime)
			if ftime < 0:
				ftime *= -1
		except:
			ftime = 5.0
		self.audio_files[0].set_file_time(ftime)

		fmax = self.entry_fmax.get()
		try:
			fmax = float(fmax)
			if fmax < 0:
				fmax *= -1
		except:
			fmax = 2.0

		self.audio_files[0].set_amp_max(fmax)

	# Update Graph
	def update_file(self):
		self.update_from_application()
		self.functions.update_audio()
		self.filters.update_audio()
		self.graph.update_graph()

	# Save, update graph first
	def save_file(self):
		self.update_file()
		self.audio_files[0].save_file()

	def finish(self):
		#print ('Application.finish')
		self.update_from_application()
		print (self.audio_files[0].get_all())
		try:
			self.option_window.master.destroy()
		except:
			pass
		self.master.destroy()

###
