# Brutal Editor
# Audio Version 0.1
# main.py
# >>> python2
# Feb 24, 2016
#
# main function 
# 	just initialize and go
#

try:
	import Tkinter as tk
except ImportError:
	import tkinter as tk

import modules.Application as Application
import modules.Style as Style

size_app_minw = Style.size_app_minw
size_app_minh = Style.size_app_minh
size_app_maxw = Style.size_app_maxw
size_app_maxh = Style.size_app_maxh

colour_app_foreground = Style.colour_app_foreground
colour_app_background = Style.colour_app_background

def run_application():

	root = tk.Tk()
	root.config(width=900, height=540)
	app = Application.Audio_Application(master=root)
	app.master.title('Brutal Audio')
	app.master.minsize(size_app_minw, size_app_minh)
	app.master.maxsize(size_app_maxw, size_app_maxh)
	app.tk_setPalette(background=colour_app_background, foreground=colour_app_foreground)
	root.protocol('WM_DELETE_WINDOW', app.finish)
	try:
		app.mainloop()
		return 1
	except:
		return 0
	return

if __name__ == "__main__":
	run_application()

###
