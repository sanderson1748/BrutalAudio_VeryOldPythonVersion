# Brutal Editor
# Audio Version 0.1
# Graph.py
# >>> python2
# Feb 24, 2016
#
# Displays graph
#

try:
	import Tkinter as tk
except:
	import tkinter as tk
import numpy as np

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt 	#import last (for matplotlib)

import Audio
import Style

colour_graph_background = Style.colour_graph_background
colour_graph_lines = Style.colour_graph_lines
colour_app_background = Style.colour_app_background
colour_frame_background = Style.colour_frame_background

plt.ion()				# yes

class Graph_Window(tk.Frame):

	def __init__(self, master, audio_file):

		tk.Frame.__init__(self, master)
		self.audio_file = audio_file

		self.figure = Figure(dpi=None, facecolor=colour_app_background)

		self.ax = self.figure.add_subplot(111) # class = matplotlib.axes.Axes

		self.canvas = FigureCanvasTkAgg(self.figure, master=self.master)
		self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
		self.canvas.get_tk_widget().config(bg=colour_frame_background)
		self.figure.tight_layout(pad=5.0)

		'''
		self.toolbar = NavigationToolbar2TkAgg(self.canvas, self)
		self.toolbar.update()
		self.canvas._tkcanvas.pack()
		'''

		# go
		self.update_graph()

	def update_graph(self):
		#print ('Graph.update_graph')

		# prep
		update = self.audio_file.get_all()
		time = self.audio_file.get_file_time()

		x = np.linspace(0, time, 10000) 	# 10,000 for now
		y = self.get_y(x, update)

		self.ax.clear()
		self.ax.plot(x, y)

		maxp = self.audio_file.get_amp_max() 	# max power
		maxpint = int(maxp) + 1

		# vertical grids
		yy = [(i / 2.0) for i in range(2*int(time) + 2)]
		self.ax.vlines(yy, -1*maxpint, maxpint + 2, color=colour_graph_lines)
		self.ax.set_ylim((-1*maxp), maxp)

		# horizontal grids
		xx = [(i/2.0) for i in range((-2*maxpint), (2*maxpint))]
		self.ax.hlines(xx, 0, time, color=colour_graph_lines)
		self.ax.set_xlim(0, time)

		# graph placement/things
		self.ax.set_xlabel('Time (s)', labelpad=0.75)
		self.ax.set_ylabel('Amplitude', labelpad=1.0, rotation='horizontal')

		# go
		self.canvas.draw()

	# returns linspace for y
	# accepts 
	#	x = np.linspace(...)
	#	update = self.audio_file.get_all()
	def get_y(self, x, update):
		#print ('Graph.get_y update is ' + str(update))

		try: 
			# Base
			if update[1][0] == np.sin:
				y = update[1][1] * np.sin(update[1][2] * x + update[1][3]) + update[1][4]
			else:
				raise Audio.AudioException(0, 'Graph.update_audio: base function not sin')

			# Functions
			for i in range(len(update[2])):
				if update[2][i][0] == np.sin:
					y += update[2][i][1] * np.sin(update[2][i][2] * x + update[2][i][3]) + update[2][i][4]
				else:
					raise Audio.AudioException(0, 'Graph.update_audio: functions not sin at ' + str(i))

			# Filters
			for i in range(len(update[3])):
				if update[3][i][0] == np.sin:
					y *= update[3][i][1] * np.sin(update[3][i][2] * x + update[3][i][3]) + update[3][i][4]
				else:
					raise Audio.AudioException(0, 'Graph.update_audio: filters not sin at ' + str(i))

			return y

		except:
			return np.sin(x)

###
