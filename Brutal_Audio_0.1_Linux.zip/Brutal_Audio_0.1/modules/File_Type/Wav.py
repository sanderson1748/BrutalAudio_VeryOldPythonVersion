# Brutal Editor
# Audio V 0.1
# Wav.py
# >>> python2
# Feb 24, 2016
# 
# makes file as .wav
# 
# running send to bits_n() functions for now, will upgrade later
#

import os
import struct
import numpy as np
import time

# audio_data = Audio.get_all()
# when processing file names, file_name should not have extension
def process_wav(audio_data):
	#print ('Process_File.Wav.process_wav audio_data: ' + str(audio_data))

	s = process_data(audio_data)

	if audio_data[0][3].endswith('/'):
		file_save_loc = audio_data[0][3] + audio_data[0][4]
	else:
		file_save_loc = audio_data[0][3] + '/' + audio_data[0][4]

	try:
		with open(file_save_loc + '.' + audio_data[0][0], 'wb') as ftmp:
			ftmp.write(s)
	except IOError:
		os.system('mkdir -p ' + str(audio_data[0][3]))

		with open(file_save_loc + '.' + audio_data[0][0], 'wb') as ftmp:
			ftmp.write(s)

	with open(file_save_loc + '.txt', 'w') as ftmp:
		ftmp.write(str(audio_data))

def process_data(audio_data):
	s1 = process_head(audio_data)
	s2 = process_body(audio_data)
	s3 = process_foot(audio_data)
	return (s1 + s2 + s3)

# Head is 44 bytes, has all data
def process_head(audio_data):
	#print ('File_Type.Wav.process_head audio_data: ' + str(audio_data))

	byte_tot = audio_data[4][2] * audio_data[0][1]
	byte_rate = audio_data[4][2] * audio_data[4][1] * audio_data[4][4] / 8.0
	chunk = byte_tot - 8
	sub2_size = (byte_tot - 44) * audio_data[4][1] * audio_data[4][4] / 8.0

	# 00 - "RIFF"
	s = b'\x52\x49\x46\x46'

	# 04 - chunk
	s += struct.pack('<I', chunk)

	# 08 - "WAVEfmt "
	s += b'\x57\x41\x56\x45\x66\x6d\x74\x20'

	# 16 - sub1 size
	s += struct.pack('<I', audio_data[4][0])

	# 20 - indicate PCM
	s += b'\x01\x00'

	# 22 - channels
	s += struct.pack('<H', audio_data[4][1])

	# 24 - sample rate
	s += struct.pack('<I', audio_data[4][2])

	# 28 - byte rate
	s += struct.pack('<I', byte_rate)

	# 32 - block align
	s += struct.pack('<H', audio_data[4][3])

	# 34 - bits per sample
	s += struct.pack('<H', audio_data[4][4])

	# 36 - "DATA"
	s += b'\x64\x61\x74\x61'

	# 40 - sub2 size
	s += struct.pack('<I', sub2_size)

	return s

# evaluates y = F(theta)
# 	      = (fbase(theta) + Sigma[functions(theta)]) * Pi[filters(theta)]
def process_body(audio_data):
	#print ('File_Type.Wav.process_body')

	s = b''
	byte_tot = audio_data[4][2] * audio_data[0][1]
	sub2_size = (byte_tot - 44) * audio_data[4][1] * audio_data[4][4] / 8.0
	bits_per_sample = audio_data[4][4]
	#print ('sub2size ' + str(sub2_size)) 

	#function_max = get_function_max(audio_data)
	function_max = audio_data[0][2]

	for i in range(int(sub2_size)):
		y = 0.0
		theta = i / float(audio_data[4][2])

		# Base Function
		if audio_data[1][0] == np.sin:
			y = evaluate_sin(audio_data[1], theta)
		else:
			raise Audio.Audio_Error(0, 'Wav.process_body base function has improper type')

		# Other Functions
		for j in range(len(audio_data[2])):
			if audio_data[2][j][0] == np.sin:
				y += evaluate_sin(audio_data[2][j], theta)
			else:
				raise Audio.Audio_Exception(0, 'Wav.process_body functions has improper type at ' + str(j))

		# Filters	
		for j in range(len(audio_data[3])):
			if audio_data[3][j][0] == np.sin:
				y *= evaluate_sin(audio_data[3][j], theta)
			else:
				raise Audio.Audio_Exception(0, 'Wav.process_body filters has improper type at ' + str(j))

		if bits_per_sample == 8:
			s += to_sample_8(y, function_max)
		else:
			raise (Audio.Audio_Exception(0, 'Wav.process_body bits per sample not right'))

	return s

def lamb(ins):
	return lambda theta: (ins[1] * np.sin(ins[2] * theta + ins[3]) + ins[4])

def process_foot(audio_data):
	return b'\x42\x72\x75\x74\x61\x6c\x20\x41\x75\x64\x69\x6f' # 'Brutal Audio'

# ins are one tuple of sin stuff
# y = Asin(freq * theta + phi) + const
def evaluate_sin(ins, theta):
	return (ins[1] * np.sin(ins[2] * theta + ins[3]) + ins[4])

# dummy for now, run 0/1/2
def evaluate_funcional(ins, theta):
	return 1

###############
# to_sample_n
# return the bit of string to be appended to final string
#	first bit is 0/1 for -/+
#	rest is calculated with get_sample_n
#		get_sample_n accepts |y|
# bit_max    = 2 ** bits_per_sample 
# sample_max = 2 ** (bits_per_sample - 1) - 1
#	--> (bits_per_sample - 1 (for +/- slot)) - 1 (for 0 slot)
# 	bit_max = 256, sample_max = 127
###############

###############
# 16 bit is -32768 -> 32767
# 24 bit is -2^23 -> 2^23 -1
###############

# bit_max    = 256
# sample_max = 127
# returns 8 bits
def to_sample_8 (y, function_max):
	if y > 0:
		s = 128
		return (get_sample_8(y, s, function_max)) 
	else:
		s = 0
		y *= -1
		return (get_sample_8(y, s, function_max, positive=False)) 

# bit_max = 256
# sample_max = 127
# get > (y / function_max) = (go / sample_max)
# 	go = y * sample_max / function_max
def get_sample_8(y, s, function_max, positive=True):
	val1 = y * 127 / function_max
	val2 = s | int(val1)
	try:
		return struct.pack('B', val2)
	except:
		#print ('val2 = ' + str(val2))
		if val2 > 255:
			if (positive):
				val2 = 255
			else:
				val2 = 0

		return struct.pack('B', val2)

###
