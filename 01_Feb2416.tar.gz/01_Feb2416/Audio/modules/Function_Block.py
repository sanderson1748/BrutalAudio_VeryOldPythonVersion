# Brutal Editor
# Audio V0
# Function_Block.py
# >>> python2
# Dec 14, 2015
# 
# choose: 0 = functions, 1 = filters
# 
#

import Tkinter as tk
import numpy as np

import Audio
import Style

colour_app_background = Style.colour_app_background

colour_button = Style.colour_button 
colour_entry  = Style.colour_entry
colour_label  = Style.colour_label
colour_label_header = Style.colour_label_header

class Function_Block(tk.Frame):

	def __init__(self, choose, master=None, audio_file=None):

		tk.Frame.__init__(self, master)
		self.choose = choose
		self.label_list = []
		self.audio_file = audio_file

		self.label_main = tk.Label(self.master, bg=colour_label_header)
		if self.choose == 0:
			self.label_main.config(text='Functions', bg=colour_label_header)
		elif self.choose == 1:
			self.label_main.config(text='Filters', bg=colour_label_header)
		else: 
			raise Audio.Audio_Exception(0, 'Function_Block.__init__ choose bad ' +  str(choose))

		self.label_main.place(relx=0.0, rely=0.00, relwidth=1.0, relheight=0.10)
		self.button_add = tk.Button(self.master, text='Add', bg=colour_button, command=self.add_listing)
		self.button_add.place(relx=0.0, rely=0.90, relwidth=1.0, relheight=0.10)

		try:
			if self.choose == 0:
				tmp = audio_file.get_all()[2]
				tmp.insert(0, audio_file.get_all()[1])
				self.load_labels(tmp)

			elif self.choose == 1:
				self.load_labels(audio_file.get_all()[3])

		except Exception, e:
			print ('Function_Block init issues' + str(e))
			self.load_labels()

	def load_labels(self, hold=[]):
		#print ('Function_Block.load_labels hold = ' + str(hold))

		try:
			for i in range(len(hold)):
				self.add_listing(hold[i], first=True)
			self.update_labels()

		except Exception, e:
			raise Audio.Audio_Exception(0, 'Function_Block.load_labels calls self.add_listing() error: ' + str(e))

	# add function to functions/filters
	# calls make_tuple_x to create listings
	# first only true on class instantiation, just to save from calling print_labels() too many times
	# hold=1 is a fresh entry, call sin
	def add_listing(self, hold=1, first=False):
		#print ('Function_Block.add_listing len(label_list) = ' + str(len(self.label_list)))

		if len(self.label_list) > 7:
			pass
		else: 
			if hold == 1:
				tmp = self.make_tuple_sin(hold)
				self.label_list.append(tmp)
			elif hold[0] == np.sin:
				tmp = self.make_tuple_sin(hold)
				self.label_list.append(tmp)
			#elif hold[0] == functional:
			else:
				raise Audio.Audio_Exception(0, 'Function_Block.add_listing bad type')

			if not first:
				self.update_labels()

		self.update_button_availability()

	# formatted for label_list
	# adjusting button commands are done in self.update_labels
	# hold is (np.sin, amp, freq, phi, const)
	def make_tuple_sin(self, hold):
		#print ('Function_Block.make_tuple_sin')

		tmp_amp = tk.Entry(self.master)
		tmp_freq = tk.Entry(self.master)
		tmp_phi = tk.Entry(self.master)
		tmp_const = tk.Entry(self.master)

		try:
			tmp_amp.insert(0,str(hold[1]))
			tmp_freq.insert(0,str(hold[2]))
			tmp_phi.insert(0,str(hold[3]))
			tmp_const.insert(0,str(hold[4]))
			s = 'f(x) = ' + str(hold[1]) + 'sin(' + str(hold[2]) + 'x + ' + str(hold[3]) + ') + ' + str(hold[4])

		except:
			tmp_amp.insert(0, '1')
			tmp_phi.insert(0, '0')
			tmp_const.insert(0, '0')
			if self.choose == 1:
				tmp_freq.insert(0, '10')
				s = 'f(x) = ' + '1' + 'sin(' + '10' + 'x + ' + '0' + ') + ' + '0'
			else:
				tmp_freq.insert(0, '110')
				s = 'f(x) = ' + '1' + 'sin(' + '110' + 'x + ' + '0' + ') + ' + '0'

		# controls
		tmp_display= tk.Label(self.master, text=s, bg=colour_label)
		tmp_button_select = tk.Button(self.master, text='Select', bg=colour_button)
		tmp_button_remove = tk.Button(self.master, text='Remove', bg=colour_button)

		go = tmp_display, tmp_amp, tmp_freq, tmp_phi, tmp_const, tmp_button_select, tmp_button_remove
		for i in range(1, 5):
			go[i].config(bg=colour_entry, justify=tk.RIGHT)

		return go

	# DOES NOT clear labels -> do that first
	def update_labels(self):
		#print ('Function_Block::update_lables called')

		for i in range(len(self.label_list)):
			self.label_list[i][1].bind(sequence='<FocusOut>', func=lambda event=i, i=i: self.update_single_line(event, i))
			self.label_list[i][2].bind(sequence='<FocusOut>', func=lambda event=i, i=i: self.update_single_line(event, i))
			self.label_list[i][3].bind(sequence='<FocusOut>', func=lambda event=i, i=i: self.update_single_line(event, i))
			self.label_list[i][4].bind(sequence='<FocusOut>', func=lambda event=i, i=i: self.update_single_line(event, i))
			self.label_list[i][5].config(command=lambda i=i: self.select_listing(i))
			self.label_list[i][6].config(command=lambda i=i: self.remove_listing(i))

		self.print_labels()
		self.update_audio()

	# get number, do gets, make new tuple, replace into label_list, refresh
	# need an add focus point somewhere as well
	def update_single_line(self, event, i):
		#print ('Function_Block.update_single_line i = ' + str(i))

		if True:
		#if self.label_list[i][0].get().find('sin') > 0:
			try: 
				b = float(self.label_list[i][1].get())
			except:
				b = 1.0
			if b.is_integer():
				sB = str(b).split('.')[0]
			else:
				sB = str(b)

			try:
				c = float(self.label_list[i][2].get())
			except:
				c = 440.0
			if c.is_integer():
				sC = str(c).split('.')[0]
			else:
				sC = str(c)

			try:
				d = float(self.label_list[i][3].get())
			except:
				d = 0
			if d.is_integer():
				sD = str(d).split('.')[0]
			else:
				sD = str(d)

			try:
				e = float(self.label_list[i][4].get())
			except:
				e = 0
			if e.is_integer():
				sE = str(e).split('.')[0]
			else:
				sE = str(e)

			s = 'f(x) = ' + sB + 'sin(' + sC + 'x + ' + sD + ') + ' + sE

		else:
			raise Audio.Audio_Exception(0, 'Function_Block.update_single_line i != np.sin')

		self.label_list[i][0].config(text=s)
		self.update_audio()

	# remove from palette, but no deletes
	def clear_labels(self):
		for i in range(len(self.label_list)):
			for j in range(len(self.label_list[i])):
				self.label_list[i][j].place_forget()

	# places labels onto this palette
	def print_labels(self):
		n = len(self.label_list)
		if n > 0:
			for i in range(len(self.label_list)):
				self.label_list[i][0].place(relx=0.000, rely=(0.10+i*0.10), relwidth=0.400, relheight=0.1)
				self.label_list[i][1].place(relx=0.400, rely=(0.10+i*0.10), relwidth=0.075, relheight=0.1)
				self.label_list[i][2].place(relx=0.475, rely=(0.10+i*0.10), relwidth=0.075, relheight=0.1)
				self.label_list[i][3].place(relx=0.550, rely=(0.10+i*0.10), relwidth=0.075, relheight=0.1)
				self.label_list[i][4].place(relx=0.625, rely=(0.10+i*0.10), relwidth=0.075, relheight=0.1)
				self.label_list[i][5].place(relx=0.700, rely=(0.10+i*0.10), relwidth=0.150, relheight=0.1)
				self.label_list[i][6].place(relx=0.850, rely=(0.10+i*0.10), relwidth=0.150, relheight=0.1)

			#may have to do an event FocusOut or something
			m = len(self.label_list[n-1])
			self.button_add.lower(self.label_list[n-1][m-1])

	# hides button if list is full
	def update_button_availability(self):
		if len(self.label_list) > 7:
			self.button_add.config(relief='flat', state=tk.DISABLED, bg=colour_button)
			self.button_add.config(relief='flat', state=tk.DISABLED)
		else: 
			self.button_add.config(relief='raised', state=tk.NORMAL, bg=colour_app_background)
			self.button_add.config(relief='raised', state=tk.NORMAL)

	# new_tuple is tuple that has been updated by make_tuple_sin already
	def replace_listing(self, new_tuple, at):
		#print ('Function_Block.replace_listing')
		if self.choose == 0: 
			self.remove_listing(at, trust_me=True)
		else:
			self.remove_listing(at)
		self.label_list.insert(at, new_tuple)

	# used to switch between sin and functional
	# i is coming in as index -> makes lambda i=i work, dunno
	def select_listing(self, i):
		#print ('Function_Block::select_listing select = ' + str(i))
		a, b, c, d, e, f, g = self.label_list[i]

		tmp_label = tk.Label(self.master, text='updated')

		tmp = (tmp_label, b, c, d, e, f, g)
		self.remove_listing(i, trust_me=True)
		self.label_list.insert(i, tmp)
		self.update_labels()

	# if functions will block deleting the last entry
	# trust_me is an override
	#	when select_listing is used on base_function
	def remove_listing(self, i, trust_me=False):
		#print('Function_Block::remove_listing i = ' + str(i))

		self.clear_labels()

		if self.choose == 0:
			if len(self.label_list) == 1:
				if not trust_me:
					self.label_list.pop(0)
					tmp = (np.sin, 1, 10, 0, 0)
					self.add_listing(tmp)
					self.update_button_availability()
					return

		self.label_list.pop(i)
		self.update_button_availability()
		self.update_labels()

	# returns/updates info for Audio file
	# ( fun/fil, [(those functions),..] )
	def update_audio(self):
		#print ('Function_Block.update_audio called')

		func = []
		for i in range(len(self.label_list)):
			# need a sin check
			#if self.label_list[i][0] == np.sin: # is no good
			func.append(self.for_update_sin(self.label_list[i]))
			#else:
			#	raise Audio.Audio_Exception(0, 'Function_Block.update_audio bad type')

		self.audio_file.update_audio((self.choose, func))

	# just for packing to update; if sin
	# n is a label_list line 
	def for_update_sin(self, n):
		#print ('Function_Block.for_update_sin incoming is: ' + str(n))

		try:
			amp = float (n[1].get())
		except ValueError:
			amp = 1.0
			n[1].delete(0, 1000)
			n[1].insert(0, '1')
		### 
		# for harmonics
		# if n[2].get() == 'f':
		###

		try:
			freq = float (n[2].get())
		except ValueError:
			freq = 100
			n[2].delete(0, 1000)
			n[2].insert(0, freq)
		try:
			phi = float (n[3].get())
		except ValueError:
			phi = 0
			n[3].delete(0, 1000)
			n[3].insert(0, phi)
		try:
			const = float (n[4].get())
		except ValueError:
			const = 0
			n[4].delete(0, 1000)
			n[4].insert(0, const)

		ret = (np.sin, amp, freq, phi, const)
		return (ret)  

###
