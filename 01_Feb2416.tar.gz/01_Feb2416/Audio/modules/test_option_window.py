"""
JUST FOR TESTS
"""
# Brutal Editor
# Audio V0
# python_main.py
# >>> python2
# Dec 14, 2015
#
# main function for audio 
# - just initialize and go
#

import Tkinter as tk
import Application
import threading
import Option_Window 
import Audio

def run_application():

	root = tk.Tk()
	root.config(bg='black', width=175, height=200)
	a = Audio.Audio_File()

	app = Option_Window.Option_Window(a, master=root)
	app.master.title('Test Options')
	app.mainloop()

if __name__ == "__main__":
	run_application()

