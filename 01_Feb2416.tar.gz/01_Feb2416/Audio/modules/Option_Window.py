# Brutal Editor
# Audio V0
# Option_Window.py
# >>> python2
# Feb 10, 2016
# 
#

import Tkinter as tk
import numpy as np

import Audio
import Style

size_opt_width  = Style.size_opt_width
size_opt_height = Style.size_opt_height

colour_button = Style.colour_button
colour_entry  = Style.colour_entry
colour_label  = Style.colour_label

class Option_Window(tk.Frame):

	def __init__(self, audio_file, master=None):
		tk.Frame.__init__(self, master)
		self.audio_file = audio_file

		self.master.title('File Options')
		self.master.maxsize(size_opt_width, size_opt_height)
		self.master.minsize(size_opt_width, size_opt_height)

		self.load_form()

	def load_form(self):
		physical = self.audio_file.get_physical()
		y = 1.0 / 6

		self.radio_pick_wav = tk.Radiobutton(self.master, text='wav', bg=colour_button)
		self.radio_pick_wav.place(relx=0.0, rely=(0*y), relwidth=1.0, relheight=y)

		self.entry_channels = tk.Entry(self.master, bg=colour_entry, justify=tk.RIGHT)
		self.entry_channels.insert(0, str(physical[1]))
		self.entry_channels.place(relx=0.00, rely=(1*y), relwidth=0.33, relheight=y)
		self.entry_channels.bind(sequence='<FocusOut>', func=self.check_entry_channels)
		self.label_channels = tk.Label(self.master, text='Channels', bg=colour_label)
		self.label_channels.place(relx=0.33, rely=(1*y), relwidth=0.67, relheight=y)

		self.entry_samples = tk.Entry(self.master, bg=colour_entry, justify=tk.RIGHT)
		self.entry_samples.insert(0, str(physical[2]))
		self.entry_samples.place(relx=0.0, rely=(2*y), relwidth=0.33, relheight=y)
		self.entry_samples.bind(sequence='<FocusOut>', func=self.check_entry_samples)
		self.label_samples = tk.Label(self.master, text='Sample Rate', bg=colour_label)
		self.label_samples.place(relx=0.33, rely=(2*y), relwidth=0.67, relheight=y)

		self.entry_bitsper = tk.Entry(self.master, bg=colour_entry, justify=tk.RIGHT)
		self.entry_bitsper.insert(0, str(physical[4]))
		self.entry_bitsper.place(relx=0.00, rely=(3*y), relwidth=0.33, relheight=y)
		self.entry_bitsper.bind(sequence='<FocusOut>', func=self.check_entry_bitsper)
		self.entry_bitsper.config(state=tk.DISABLED)
		self.label_bitsper = tk.Label(self.master, text='Bits Per Sample', bg=colour_label)
		self.label_bitsper.place(relx=0.33, rely=(3*y), relwidth=0.67, relheight=y)

		self.entry_locate = tk.Entry(self.master, bg=colour_entry, justify=tk.LEFT)
		self.entry_locate.insert(0, self.audio_file.get_full_location() + '.' + self.audio_file.get_flavour())
		self.entry_locate.place(relx=0.00, rely=(4*y), relwidth=0.67, relheight=y)
		self.button_locate = tk.Button(self.master, bg=colour_button, text='Browse', relief='flat')
		self.button_locate.place(relx=0.67, rely=(4*y), relwidth=0.33, relheight=y)

		self.button_reset = tk.Button(self.master, bg=colour_button, text='Reset', command=self.reset)
		self.button_reset.place(relx=0.00, rely=(5*y), relwidth=0.50, relheight=y)

		self.button_close = tk.Button(self.master, bg=colour_button, text='Done', command=self.finish)
		self.button_close.place(relx=0.50, rely=(5*y), relwidth=0.50, relheight=y)

	def reset(self):
		physical = (16, 2, 44100, 4, 8)

		self.radio_pick_wav.select()

		tmp = len(self.entry_channels.get())
		self.entry_channels.delete(0, tmp)
		self.entry_channels.insert(0, str(physical[1]))

		tmp = len(self.entry_samples.get())
		self.entry_samples.delete(0, tmp)
		self.entry_samples.insert(0, str(physical[2]))

		tmp = len(self.entry_bitsper.get())
		self.entry_bitsper.delete(0, tmp)
		self.entry_bitsper.insert(0, str(physical[4]))

		tmp = len(self.entry_locate.get())
		self.entry_locate.delete(0, tmp)
		self.entry_locate.insert(0, 'Brutal/output.wav')
		
	# updates all audio components and closes window
	# cross check if extensions should be added -> they shouldn't be tho 
	def update_to_application(self):
		# physical
		try:
			physical = (16, int(self.entry_channels.get()), int(self.entry_samples.get()), 4, int(self.entry_bitsper.get()))
		except:
			physical = (16, 2, 44100, 4, 8)

		self.audio_file.set_physical(physical)

		# audio
		try:
			hold = self.entry_locate.get().partition('/')
			if hold[1] != '':
				self.audio_file.set_file_loc(hold[0] + '/')
				name = hold[2]
			else:
				self.audio_file.set_file_loc('./')
				name = hold[0]

			# may take out and have extentions added during processing
			if self.audio_file.get_flavour() == 'wav': 
				if name.endswith('.wav'):
					hold = name.partition('.')
					self.audio_file.set_file_name(hold[0])
				else:
					self.audio_file.set_file_name(name)
			else:
				raise Audio.Audio_Exception (0, 'Option_Window.update_to_application flavour error')
			
		except:
			self.audio_file.set_file_loc('./')

			if self.audio_file.get_flavour() == 'wav': 
				self.audio_file.set_file_name('output')
			else:
				raise Audio.Audio_Exception (0, 'Option_Window.update_to_application flavour error')

	# update files and hide window
	def finish(self):
		self.update_to_application()
		self.master.withdraw()

	def check_entry_channels(self, event):
		try:
			hold = int(self.entry_channels.get())
			if hold not in (1, 2):
				raise
		except:
			self.entry_channels.delete(0, 1000) 
			self.entry_channels.insert(0, '2')

	def check_entry_samples(self, event):
		try:
			hold = int(self.entry_samples.get())
			if hold not in range (10000, 200000):
				raise
		except:
			self.entry_samples.delete(0, 1000)
			self.entry_samples.insert(0, '44100')

	def check_entry_bitsper(self, event):
		try:
			hold = int(self.entry_bitsper.get())
			if hold != 8:
				raise
		except:
			self.entry_bitsper.delete(0, 1000)
			self.entry_bitsper.insert(0, '8')

### 
